<h1>Cloud Racer</h1>
<h3>To run the program perform the following steps:</h3>
<ol>
  <li>Download the 'CloudRacerFiles.zip' file from the repoistory</li>
  <li>Upload all the files within the zip file to your Google Drive under the directory 'Colab Notebooks/CloudRacer'</li>
  <li>Open CloudRacer.ipynb from the repository > Click 'Open in Colab'</li>
  <li>From toolbar on top (in Google Colab) select Runtime > Run all</li>
  <li>Connect your Google Drive when the popup window requests it</li>
  <li>To log into the application as a player insert {username:'player', password:'123'}<br>To log in as an admin insert {username:'admin', password:'12345'}</li>
  <li>Enjoy!</li>
</ol>

<span>Application Developed by Alligators Team</span>
<h5>Team Members:</h5>
<ol>
  <li>Mahran Abdellatif</li>
  <li>Amran Zoabi</li>
  <li>Shadi Abdelkarim</li>
  <li>Shokry Arraf</li>
  <li>Mohammed Khateeb</li>
</ol>
